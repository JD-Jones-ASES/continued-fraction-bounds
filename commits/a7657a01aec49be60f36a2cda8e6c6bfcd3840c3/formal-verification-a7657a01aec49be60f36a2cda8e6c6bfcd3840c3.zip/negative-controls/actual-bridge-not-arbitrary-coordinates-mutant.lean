module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example {α : ℝ} (hα : Irrational α) (n : ℕ) (x y : ℝ) :
    minimumTriple α n = lower (digit α (n+2)) x y := by
  exact actual_minimum_eq hα n
