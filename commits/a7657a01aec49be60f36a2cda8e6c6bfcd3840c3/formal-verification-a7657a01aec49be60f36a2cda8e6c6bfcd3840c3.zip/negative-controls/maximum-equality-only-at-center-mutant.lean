module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example {a x y : ℝ} (ha : 2 ≤ a) (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hy : 0 ≤ y) (hy1 : y ≤ 1) :
    (upper a x y-threshold a = upperStabilityConstant a * max |x-metallic a| |y-metallic a|) ↔
      ((x = metallic a ∧ y = metallic a) ∨ (x = 1 ∧ y = 1/(a+1))) := by
  exact global_upper_stability_eq_iff ha hx hx1 hy hy1
