module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example : sharpLowerDigitThreshold 2 1 = (10/29 : ℝ) := by
  exact silver_sharp_window_one.1
