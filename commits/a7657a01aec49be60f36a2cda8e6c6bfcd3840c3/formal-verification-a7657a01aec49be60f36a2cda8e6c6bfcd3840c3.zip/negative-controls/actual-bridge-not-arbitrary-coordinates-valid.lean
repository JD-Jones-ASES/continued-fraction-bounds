module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example {α : ℝ} (hα : Irrational α) (n : ℕ) (x y : ℝ) :
    minimumTriple α n = lower (digit α (n+2)) (past α n) (future α n) := by
  exact actual_minimum_eq hα n
