module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example : lower 2 1 (1/3) = 3/10 := by norm_num [lower]
