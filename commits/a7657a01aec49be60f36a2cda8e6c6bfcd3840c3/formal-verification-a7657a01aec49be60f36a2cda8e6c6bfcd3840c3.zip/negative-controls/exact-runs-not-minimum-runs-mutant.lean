module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example {α : ℝ} {a : ℤ} (hα : Irrational α) (ha : 2 ≤ a)
    (n r s : ℕ) (e f : Departure) (hd : digit α (n+2) = a)
    (hp : ∀ i < r, digit α (n+1-i) = a) (hf : ∀ i < s, digit α (n+3+i) = a) :
    minimumTriple α n < runLowerBound a r s e f := by
  exact (actual_run_bounds hα ha n r s e f hd hp hf).1
