module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example {α : ℝ} (hα : Irrational α) (n : ℕ) :
    future α n ≠ (1/3 : ℝ) := by
  simpa using (future_irrational hα n).ne_rat (1/3)
