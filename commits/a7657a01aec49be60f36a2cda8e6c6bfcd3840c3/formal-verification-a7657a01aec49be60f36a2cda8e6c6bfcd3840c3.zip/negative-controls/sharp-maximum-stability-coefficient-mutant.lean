module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example {a x y : ℝ} (ha : 2 ≤ a) (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hy : 0 ≤ y) (hy1 : y ≤ 1) :
    (upperStabilityConstant a+1) * max |x-metallic a| |y-metallic a| ≤ upper a x y-threshold a := by
  exact global_upper_stability ha hx hx1 hy hy1
