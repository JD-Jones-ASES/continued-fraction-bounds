module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example : rationalMinimumSupremum 2 1 1 .low .high = (21/58 : ℚ) := by
  exact rational_silver_one_mixed.1
