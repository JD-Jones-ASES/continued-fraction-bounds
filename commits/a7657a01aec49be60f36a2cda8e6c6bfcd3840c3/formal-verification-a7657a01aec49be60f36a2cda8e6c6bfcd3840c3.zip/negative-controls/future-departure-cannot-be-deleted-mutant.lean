module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example {α : ℝ} {a : ℤ} (hα : Irrational α) (ha : 2 ≤ a)
    (n r s : ℕ) (e f : Departure) (hd : digit α (n+2) = a)
    (hp : ExactPastRun α n a r e) (hf : ∀ i < s, digit α (n+3+i) = a) :
    runUpperBound a r s e f < maximumTriple α n := by
  exact (actual_run_bounds hα ha n r s e f hd hp hf).2.2.2
