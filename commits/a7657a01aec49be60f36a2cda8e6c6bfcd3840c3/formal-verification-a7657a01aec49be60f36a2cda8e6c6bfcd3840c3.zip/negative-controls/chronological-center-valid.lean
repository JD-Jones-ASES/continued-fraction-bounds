module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example (α : ℝ) (hα : Irrational α) (n : ℕ) :
    theta α (n+1) = 1 / ((digit α (n+2) : ℝ)+past α n+future α n) := by
  exact (ordinary_convergent_triple hα n).2.1
