module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example : lower 2 1 (1/3) = 7/24 := by norm_num [lower]
