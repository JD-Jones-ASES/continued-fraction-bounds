module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example :
    upper 2 (1/2) (1/2) ≥
      min (min (upper 2 0 0) (upper 2 0 1)) (min (upper 2 1 0) (upper 2 1 1)) := by
  exact arbitrary_rectangle_upper_corners_fail
