module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example {a x y : ℝ} (ha : 2 ≤ a) (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hy : 0 ≤ y) (hy1 : y ≤ 1) :
    stabilityConstant a * max |x-metallic a| |y-metallic a| ≤ threshold a-lower a x y := by
  exact global_stability ha hx hx1 hy hy1
