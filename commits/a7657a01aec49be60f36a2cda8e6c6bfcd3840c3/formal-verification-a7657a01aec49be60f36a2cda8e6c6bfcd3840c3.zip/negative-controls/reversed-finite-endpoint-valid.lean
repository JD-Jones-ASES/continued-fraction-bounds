module
public import ContinuedFractionBounds
public section
open ContinuedFractionBounds

example : prependWord [1,1] 0 = (1/2 : ℝ) := by
  norm_num [prependWord, prependDigit]
