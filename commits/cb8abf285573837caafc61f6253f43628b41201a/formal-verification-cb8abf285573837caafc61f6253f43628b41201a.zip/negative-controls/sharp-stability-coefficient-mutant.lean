module
public import ContinuedFractionBounds.Applications
public import ContinuedFractionBounds.ContinuedFractionsWords
public import ContinuedFractionBounds.ActualRuns
public import ContinuedFractionBounds.RunChecks
public import ContinuedFractionBounds.RectangleOptimization
public section
open ContinuedFractionBounds

example {a x y : ℝ} (ha : 2 ≤ a) (hx : 0 ≤ x) (hx1 : x ≤ 1)
    (hy : 0 ≤ y) (hy1 : y ≤ 1) :
    (stabilityConstant a+1) * max |x-metallic a| |y-metallic a| ≤ threshold a-lower a x y := by
  exact global_stability ha hx hx1 hy hy1
