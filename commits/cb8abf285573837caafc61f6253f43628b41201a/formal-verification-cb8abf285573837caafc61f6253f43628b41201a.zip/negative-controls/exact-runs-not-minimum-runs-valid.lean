module
public import ContinuedFractionBounds.Applications
public import ContinuedFractionBounds.ContinuedFractionsWords
public import ContinuedFractionBounds.ActualRuns
public import ContinuedFractionBounds.RunChecks
public import ContinuedFractionBounds.RectangleOptimization
public section
open ContinuedFractionBounds

example {α : ℝ} {a : ℤ} (hα : Irrational α) (ha : 2 ≤ a)
    (n r s : ℕ) (e f : Departure) (hd : digit α (n+2) = a)
    (hp : ExactPastRun α n a r e) (hf : ExactFutureRun α n a s f) :
    minimumTriple α n < runLowerBound a r s e f := by
  exact (actual_run_bounds hα ha n r s e f hd hp hf).1
