module
public import ContinuedFractionBounds.Applications
public import ContinuedFractionBounds.ContinuedFractionsWords
public import ContinuedFractionBounds.ActualRuns
public import ContinuedFractionBounds.RunChecks
public import ContinuedFractionBounds.RectangleOptimization
public section
open ContinuedFractionBounds

example :
    upper 2 (1/2) (1/2) <
      min (min (upper 2 0 0) (upper 2 0 1)) (min (upper 2 1 0) (upper 2 1 1)) := by
  exact arbitrary_rectangle_upper_corners_fail
