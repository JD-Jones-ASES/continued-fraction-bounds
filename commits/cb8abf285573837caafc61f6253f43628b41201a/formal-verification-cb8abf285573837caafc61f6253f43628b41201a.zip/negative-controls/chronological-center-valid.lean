module
public import ContinuedFractionBounds.Applications
public import ContinuedFractionBounds.ContinuedFractionsWords
public import ContinuedFractionBounds.ActualRuns
public import ContinuedFractionBounds.RunChecks
public import ContinuedFractionBounds.RectangleOptimization
public section
open ContinuedFractionBounds

example (α : ℝ) (hα : Irrational α) (n : ℕ) :
    theta α (n+1) = 1 / ((digit α (n+2) : ℝ)+past α n+future α n) := by
  exact (ordinary_convergent_triple hα n).2.1
