module
public import ContinuedFractionBounds.Applications
public import ContinuedFractionBounds.ContinuedFractionsWords
public import ContinuedFractionBounds.ActualRuns
public import ContinuedFractionBounds.RunChecks
public import ContinuedFractionBounds.RectangleOptimization
public section
open ContinuedFractionBounds

example {α : ℝ} (hα : Irrational α) (n : ℕ) (x y : ℝ) :
    minimumTriple α n = lower (digit α (n+2)) (past α n) (future α n) := by
  exact actual_minimum_eq hα n
