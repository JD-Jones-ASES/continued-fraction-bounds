module
public import ContinuedFractionBounds.Applications
public import ContinuedFractionBounds.ContinuedFractionsWords
public import ContinuedFractionBounds.ActualRuns
public import ContinuedFractionBounds.RunChecks
public import ContinuedFractionBounds.RectangleOptimization
public section
open ContinuedFractionBounds

example {α : ℝ} (hα : Irrational α) (n : ℕ) :
    future α n ≠ (1/3 : ℝ) := by
  simpa using (future_irrational hα n).ne_rat (1/3)
