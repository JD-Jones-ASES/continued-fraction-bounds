module
public import ContinuedFractionBounds.Applications
public import ContinuedFractionBounds.ContinuedFractionsWords
public import ContinuedFractionBounds.ActualRuns
public import ContinuedFractionBounds.RunChecks
public import ContinuedFractionBounds.RectangleOptimization
public section
open ContinuedFractionBounds

example :
    max (max (lower 2 0 0) (lower 2 0 1)) (max (lower 2 1 0) (lower 2 1 1)) ≥
      lower 2 (1/2) (1/2) := by
  exact arbitrary_rectangle_lower_corners_fail
