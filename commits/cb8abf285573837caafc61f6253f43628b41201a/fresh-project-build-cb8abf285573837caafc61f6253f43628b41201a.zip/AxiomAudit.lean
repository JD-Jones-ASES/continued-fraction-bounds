import Lean.Util.CollectAxioms
import ContinuedFractionBounds.ActualRuns
import ContinuedFractionBounds.Applications
import ContinuedFractionBounds.Basic
import ContinuedFractionBounds.ClassicalBounds
import ContinuedFractionBounds.ContinuedFractions
import ContinuedFractionBounds.ContinuedFractionsFutureDensity
import ContinuedFractionBounds.ContinuedFractionsRealization
import ContinuedFractionBounds.ContinuedFractionsRunRealization
import ContinuedFractionBounds.ContinuedFractionsRunSharpness
import ContinuedFractionBounds.ContinuedFractionsRuns
import ContinuedFractionBounds.ContinuedFractionsWords
import ContinuedFractionBounds.DigitWindows
import ContinuedFractionBounds.FixedPast
import ContinuedFractionBounds.LevelSets
import ContinuedFractionBounds.LowerSwitch
import ContinuedFractionBounds.MetallicBoundary
import ContinuedFractionBounds.Quantitative
import ContinuedFractionBounds.RectangleOptimization
import ContinuedFractionBounds.Rectangles
import ContinuedFractionBounds.RunBounds
import ContinuedFractionBounds.RunChecks
import ContinuedFractionBounds.Runs
import ContinuedFractionBounds.Stability
import ContinuedFractionBounds.UpperRectangleOptimization
import ContinuedFractionBounds.UpperSwitch
import Solution

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let principal : Array String := #["ContinuedFractionBounds.convergent_eq", "ContinuedFractionBounds.ordinary_convergent_triple", "ContinuedFractionBounds.runLowerBound_extremizer", "ContinuedFractionBounds.runUpperBound_extremizer", "ContinuedFractionBounds.runBounds_rational", "ContinuedFractionBounds.actual_run_bounds", "ContinuedFractionBounds.actual_run_lower_sharp", "ContinuedFractionBounds.actual_run_upper_sharp", "ContinuedFractionBounds.global_stability", "ContinuedFractionBounds.global_stability_eq_iff", "ContinuedFractionBounds.stabilityConstant_optimal", "ContinuedFractionBounds.stabilityConstant_two", "ContinuedFractionBounds.actual_stability_strict", "ContinuedFractionBounds.actual_stabilityConstant_optimal", "ContinuedFractionBounds.near_extremizer_radius", "ContinuedFractionBounds.small_deficit_in_interval", "ContinuedFractionBounds.lower_level_iff", "ContinuedFractionBounds.upper_level_iff", "ContinuedFractionBounds.lower_eq_threshold_iff", "ContinuedFractionBounds.upper_eq_threshold_iff", "ContinuedFractionBounds.lower_rectangle_maximum", "ContinuedFractionBounds.upper_rectangle_minimum", "ContinuedFractionBounds.lower_rectangle_threshold_iff", "ContinuedFractionBounds.upper_rectangle_threshold_iff", "ContinuedFractionBounds.fixed_word_future_sequences", "ContinuedFractionBounds.exhausted_past", "ContinuedFractionBounds.metallic_irrational", "ContinuedFractionBounds.metallic_digits", "ContinuedFractionBounds.metallic_theta", "ContinuedFractionBounds.metallic_triple_even", "ContinuedFractionBounds.metallic_triple_odd", "ContinuedFractionBounds.metallic_triples_tendsto", "ContinuedFractionBounds.metallic_future_run_extrema", "ContinuedFractionBounds.metallic_low_example_states", "ContinuedFractionBounds.metallic_high_example_states", "ContinuedFractionBounds.metallic_low_example_attains", "ContinuedFractionBounds.metallic_high_example_attains", "ContinuedFractionBounds.past_ne_metallic", "ContinuedFractionBounds.infinite_future_iff_metallic", "ContinuedFractionBounds.envelopes_lipschitz", "ContinuedFractionBounds.run_constants_convergence", "ContinuedFractionBounds.small_deficit_constant_cell", "ContinuedFractionBounds.small_deficit_digit_window", "ContinuedFractionBounds.silver_one_low_high", "ContinuedFractionBounds.past_rational", "ContinuedFractionBounds.future_irrational", "ContinuedFractionBounds.runCell_shift", "ContinuedFractionBounds.runCell_eq_Icc", "ContinuedFractionBounds.runCell_interiors_disjoint", "ContinuedFractionBounds.metallic_not_mem_runCell", "ContinuedFractionBounds.fixedPastLower_extremum", "ContinuedFractionBounds.fixedPastUpper_extremum", "ContinuedFractionBounds.fixedPast_bounds_rational", "ContinuedFractionBounds.fixed_past_bounds", "ContinuedFractionBounds.fixedPast_bounds_strict_threshold", "ContinuedFractionBounds.fixed_past_lower_sharp", "ContinuedFractionBounds.fixed_past_upper_sharp", "ContinuedFractionBounds.exhausted_fixed_past_bounds", "ContinuedFractionBounds.fixed_word_metallic_realization", "ContinuedFractionBounds.terminal_one_endpoint", "ContinuedFractionBounds.exactFutureRun_iff_mem", "ContinuedFractionBounds.fixed_word_irrational_future_realization", "ContinuedFractionBounds.lower", "ContinuedFractionBounds.upper", "ContinuedFractionBounds.metallic", "ContinuedFractionBounds.threshold", "ContinuedFractionBounds.stabilityConstant", "ContinuedFractionBounds.completeQuotient", "ContinuedFractionBounds.digit", "ContinuedFractionBounds.numerator", "ContinuedFractionBounds.denominator", "ContinuedFractionBounds.theta", "ContinuedFractionBounds.past", "ContinuedFractionBounds.future", "ContinuedFractionBounds.minimumTriple", "ContinuedFractionBounds.maximumTriple", "ContinuedFractionBounds.tailMap", "ContinuedFractionBounds.tailIter", "ContinuedFractionBounds.departureLeft", "ContinuedFractionBounds.departureRight", "ContinuedFractionBounds.departureInterval", "ContinuedFractionBounds.runCell", "ContinuedFractionBounds.runEndpoint", "ContinuedFractionBounds.runLower", "ContinuedFractionBounds.runUpper", "ContinuedFractionBounds.runLowerBound", "ContinuedFractionBounds.runUpperBound", "ContinuedFractionBounds.DigitDeparture", "ContinuedFractionBounds.ExactPastRun", "ContinuedFractionBounds.ExactFutureRun", "ContinuedFractionBounds.levelBoundary", "ContinuedFractionBounds.prependDigit", "ContinuedFractionBounds.prependWord", "ContinuedFractionBounds.PositiveWord", "ContinuedFractionBounds.constantCell", "ContinuedFractionBounds.constantLower", "ContinuedFractionBounds.constantUpper", "ContinuedFractionBounds.lowerSwitch", "ContinuedFractionBounds.upperSwitch", "ContinuedFractionBounds.clip", "ContinuedFractionBounds.lowerClipLeft", "ContinuedFractionBounds.lowerClipRight", "ContinuedFractionBounds.lowerClipX", "ContinuedFractionBounds.lowerClipY", "ContinuedFractionBounds.lowerRectangleX", "ContinuedFractionBounds.lowerRectangleY", "ContinuedFractionBounds.upperClipLeft", "ContinuedFractionBounds.upperClipRight", "ContinuedFractionBounds.upperClipX", "ContinuedFractionBounds.upperClipY", "ContinuedFractionBounds.upperRectangleX", "ContinuedFractionBounds.upperRectangleY", "ContinuedFractionBounds.metallicLowExample", "ContinuedFractionBounds.metallicHighExample", "ContinuedFractionBounds.metallicNearestTail", "ContinuedFractionBounds.HasInitialWord", "ContinuedFractionBounds.wordPast", "ContinuedFractionBounds.fixedPastLowerY", "ContinuedFractionBounds.fixedPastUpperY", "ContinuedFractionBounds.fixedPastLowerBound", "ContinuedFractionBounds.fixedPastUpperBound"]
  let comparedTheorems : Array String := #["ContinuedFractionBounds.convergent_eq", "ContinuedFractionBounds.ordinary_convergent_triple", "ContinuedFractionBounds.runLowerBound_extremizer", "ContinuedFractionBounds.runUpperBound_extremizer", "ContinuedFractionBounds.runBounds_rational", "ContinuedFractionBounds.actual_run_bounds", "ContinuedFractionBounds.actual_run_lower_sharp", "ContinuedFractionBounds.actual_run_upper_sharp", "ContinuedFractionBounds.global_stability", "ContinuedFractionBounds.global_stability_eq_iff", "ContinuedFractionBounds.stabilityConstant_optimal", "ContinuedFractionBounds.stabilityConstant_two", "ContinuedFractionBounds.actual_stability_strict", "ContinuedFractionBounds.actual_stabilityConstant_optimal", "ContinuedFractionBounds.near_extremizer_radius", "ContinuedFractionBounds.small_deficit_in_interval", "ContinuedFractionBounds.lower_level_iff", "ContinuedFractionBounds.upper_level_iff", "ContinuedFractionBounds.lower_eq_threshold_iff", "ContinuedFractionBounds.upper_eq_threshold_iff", "ContinuedFractionBounds.lower_rectangle_maximum", "ContinuedFractionBounds.upper_rectangle_minimum", "ContinuedFractionBounds.lower_rectangle_threshold_iff", "ContinuedFractionBounds.upper_rectangle_threshold_iff", "ContinuedFractionBounds.fixed_word_future_sequences", "ContinuedFractionBounds.exhausted_past", "ContinuedFractionBounds.metallic_irrational", "ContinuedFractionBounds.metallic_digits", "ContinuedFractionBounds.metallic_theta", "ContinuedFractionBounds.metallic_triple_even", "ContinuedFractionBounds.metallic_triple_odd", "ContinuedFractionBounds.metallic_triples_tendsto", "ContinuedFractionBounds.metallic_future_run_extrema", "ContinuedFractionBounds.metallic_low_example_states", "ContinuedFractionBounds.metallic_high_example_states", "ContinuedFractionBounds.metallic_low_example_attains", "ContinuedFractionBounds.metallic_high_example_attains", "ContinuedFractionBounds.past_ne_metallic", "ContinuedFractionBounds.infinite_future_iff_metallic", "ContinuedFractionBounds.envelopes_lipschitz", "ContinuedFractionBounds.run_constants_convergence", "ContinuedFractionBounds.small_deficit_constant_cell", "ContinuedFractionBounds.small_deficit_digit_window", "ContinuedFractionBounds.silver_one_low_high", "ContinuedFractionBounds.past_rational", "ContinuedFractionBounds.future_irrational", "ContinuedFractionBounds.runCell_shift", "ContinuedFractionBounds.runCell_eq_Icc", "ContinuedFractionBounds.runCell_interiors_disjoint", "ContinuedFractionBounds.metallic_not_mem_runCell", "ContinuedFractionBounds.fixedPastLower_extremum", "ContinuedFractionBounds.fixedPastUpper_extremum", "ContinuedFractionBounds.fixedPast_bounds_rational", "ContinuedFractionBounds.fixed_past_bounds", "ContinuedFractionBounds.fixedPast_bounds_strict_threshold", "ContinuedFractionBounds.fixed_past_lower_sharp", "ContinuedFractionBounds.fixed_past_upper_sharp", "ContinuedFractionBounds.exhausted_fixed_past_bounds", "ContinuedFractionBounds.fixed_word_metallic_realization", "ContinuedFractionBounds.terminal_one_endpoint", "ContinuedFractionBounds.exactFutureRun_iff_mem", "ContinuedFractionBounds.fixed_word_irrational_future_realization"]
  let mut supporting : Array Name := #[]
  for (name, info) in env.constants do
    if (`ContinuedFractionBounds).isPrefixOf name then
      if info.isAxiom then
        throwError "Custom axiom in implementation namespace: {name}"
      if info.isTheorem then
        supporting := supporting.push name
  unless !supporting.isEmpty do
    throwError "No public supporting theorems found"
  let mut names := supporting
  for text in principal do
    let name := text.toName
    let some info := env.find? name | throwError "Missing compared declaration: {text}"
    if comparedTheorems.contains text && !info.isTheorem then
      throwError "Compared theorem is not a theorem: {text}"
    unless names.contains name do
      names := names.push name
  liftIO <| IO.println ("CONTINUED_FRACTION_BOUNDS_AXIOM_INVENTORY " ++ (Json.mkObj [
    ("supporting", toJson (supporting.map toString)),
    ("names", toJson (names.map toString))]).compress)
  for name in names do
    let axioms ← collectAxioms name
    liftIO <| IO.println ("CONTINUED_FRACTION_BOUNDS_AXIOM_REPORT " ++ (Json.mkObj [
      ("name", toJson name.toString),
      ("axioms", toJson (axioms.map toString))]).compress)
  liftIO <| IO.println ("CONTINUED_FRACTION_BOUNDS_AXIOM_COMPLETE " ++ toString names.size)
